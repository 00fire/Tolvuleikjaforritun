﻿using System.Numerics;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float speed = 20.0f;
    private float turnSpeed = 45.0f;
    private float horizontalInput;
    private float forwardInput;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        forwardInput = Input.GetAxis("Vertical");//vertical input movment
        horizontalInput = Input.GetAxis("Horizontal");// horizantal movement input
        //too make a coment type(//)
        transform.Translate(UnityEngine.Vector3.forward * Time.deltaTime * speed * forwardInput);//allows me too control my movment forward and backwords
        transform.Rotate(UnityEngine.Vector3.up, turnSpeed * horizontalInput * Time.deltaTime);//makes it soo in stead of sliding left and right it will rotate its movment left or right
        //transform.Translate(UnityEngine.Vector3.right * Time.deltaTime * turnSpeed * horizontalInput);// the car will go forrward ps this : UnityEngine.Vector3.forward using VSC you need too be hyper spesific 
    }
}
